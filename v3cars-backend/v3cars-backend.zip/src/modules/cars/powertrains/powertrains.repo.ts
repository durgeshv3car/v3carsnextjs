import { prisma } from '../../../lib/prisma.js';

export class PowertrainsRepo {
  async findByIds(ids: number[]) {
    if (!ids.length) return [];
    return prisma.tblmodelpowertrains.findMany({
      where: { modelPowertrainId: { in: ids } },
      select: {
        modelPowertrainId: true,
        modelId: true,
        fuelType: true,
        transmissionType: true,
        powerTrain: true,
        cylinders: true,
        cubicCapacity: true,
        claimedFE: true,
        realWorldMileage: true,
        cityMileage: true,
        highwayMileage: true,
        realWorldUrl: true,
        cityUrl: true,
        highwayUrl: true,
      },
    });
  }

  /** Return powertrain ids matching optional fuel/transmission (optionally scoped by modelId) */
  async findIdsByFilters(opts: { fuelType?: string; transmissionType?: string; modelId?: number }) {
    const where: any = {};
    if (opts.fuelType) where.fuelType = { contains: opts.fuelType };          // case-insensitive in most MySQL collations
    if (opts.transmissionType) where.transmissionType = { contains: opts.transmissionType };
    if (opts.modelId) where.modelId = opts.modelId;

    if (!Object.keys(where).length) return [];

    const rows = await prisma.tblmodelpowertrains.findMany({
      where,
      select: { modelPowertrainId: true },
    });
    return rows.map((r) => r.modelPowertrainId);
  }

  /** 🆕 Distinct modelIds that have the given fuelType (e.g., 'Electric') */
  async findModelIdsByFuel(opts: { fuelType: string }) {
    const ft = opts.fuelType?.trim();
    if (!ft) return [];
    const rows = await prisma.tblmodelpowertrains.findMany({
      where: { fuelType: { contains: ft } },   // avoids 'mode' to keep prisma happy
      select: { modelId: true },
      distinct: ['modelId'],
    });
    const set = new Set<number>();
    for (const r of rows) {
      if (typeof r.modelId === 'number') set.add(r.modelId);
    }
    return Array.from(set);
  }

  /** NEW: Distinct modelIds for combined powertrain/spec filters
   *  Handles: fuelType, transmissionType, cylinders (array or single), engineDisplacement ranges (mapped to cubicCapacity),
   *  mileage ranges (claimedFE/realWorldMileage)
   *
   *  NOTE: The DB column used for cc is `cubicCapacity` (INT).
   */
  async findModelIdsByFilters(opts: {
    fuelType?: string;
    transmissionType?: string;
    cylinders?: string | string[]; // single or array
    engineDisplacement?: string; // keys like '1000_1500' (we map this to cubicCapacity ranges)
    mileage?: string; // 'UNDER_10','BETWEEN_10_15','ABOVE_15'
  }) {
    const where: any = {};

    if (opts.fuelType) where.fuelType = { contains: opts.fuelType };
    if (opts.transmissionType) where.transmissionType = { contains: opts.transmissionType };

    // cylinders: allow array OR single value
    if (opts.cylinders) {
      const cyls = Array.isArray(opts.cylinders) ? opts.cylinders : [opts.cylinders];
      const clauses: any[] = [];
      for (const cval of cyls) {
        if (cval === '8_PLUS') {
          clauses.push({ cylinders: { gte: 8 } });
        } else {
          const c = Number(cval);
          if (!Number.isNaN(c)) clauses.push({ cylinders: c });
        }
      }
      if (clauses.length === 1) where.AND = [...(where.AND ?? []), clauses[0]];
      else if (clauses.length > 1) where.OR = [...(where.OR ?? []), ...clauses];
    }

    // engineDisplacement mapping → use cubicCapacity field (INT)
    if (opts.engineDisplacement) {
      const map: Record<string, { min?: number; max?: number }> = {
        '800': { max: 800 },
        '1000': { min: 1000, max: 1000 },
        '800_1000': { min: 800, max: 1000 },
        '1000_1500': { min: 1000, max: 1500 },
        '1500_2000': { min: 1500, max: 2000 },
        '2000_3000': { min: 2000, max: 3000 },
        '3000_4000': { min: 3000, max: 4000 },
        'ABOVE_4000': { min: 4000 },
      };
      const r = map[opts.engineDisplacement];
      if (r) {
        if (r.min != null && r.max != null) where.cubicCapacity = { gte: r.min, lte: r.max };
        else if (r.min != null) where.cubicCapacity = { gte: r.min };
        else if (r.max != null) where.cubicCapacity = { lte: r.max };
      }
    }

    // mileage mapping — use claimedFE OR realWorldMileage
    if (opts.mileage) {
      if (opts.mileage === 'UNDER_10') {
        where.OR = [...(where.OR ?? []), { claimedFE: { lt: 10 } }, { realWorldMileage: { lt: 10 } }];
      } else if (opts.mileage === 'BETWEEN_10_15') {
        where.OR = [...(where.OR ?? []), { claimedFE: { gte: 10, lt: 15 } }, { realWorldMileage: { gte: 10, lt: 15 } }];
      } else if (opts.mileage === 'ABOVE_15') {
        where.OR = [...(where.OR ?? []), { claimedFE: { gte: 15 } }, { realWorldMileage: { gte: 15 } }];
      }
    }

    // If no filters were added, return empty
    if (!Object.keys(where).length) return [];

    // distinct modelId
    const rows = await prisma.tblmodelpowertrains.findMany({
      where,
      select: { modelId: true },
      distinct: ['modelId'],
    });

    const set = new Set<number>();
    for (const r of rows) {
      if (typeof r.modelId === 'number') set.add(r.modelId);
    }
    return Array.from(set);
  }

  /** Per-model specs from the FIRST powertrain row by ASC(modelPowertrainId) */

  async getSpecsByModelIds(modelIds: number[]) {
    const map = new Map<
      number,
      {
        powerPS: number | null;
        torqueNM: number | null;
        mileageKMPL: number | null;
        powerTrain: string | null;
        transmissionType: string | null;
        transmissionSubType: string | null;
        drivetrain: number | null;
        isFourByFour: boolean | null;
      }
    >();
    if (!modelIds?.length) return map;

    // Step 1: get the MIN(modelPowertrainId) per modelId
    const mins = await prisma.tblmodelpowertrains.groupBy({
      by: ['modelId'],
      where: { modelId: { in: modelIds } },
      _min: { modelPowertrainId: true },
    });

    const ptIds: number[] = [];
    for (const g of mins) {
      const mid = g.modelId as number;
      const minId = g._min.modelPowertrainId as number | null;
      if (typeof mid === 'number' && typeof minId === 'number') {
        ptIds.push(minId);
      }
    }

    if (!ptIds.length) return map;

    const rows = await prisma.tblmodelpowertrains.findMany({
      where: { modelPowertrainId: { in: ptIds } },
      select: {
        modelId: true,
        modelPowertrainId: true,
        powerPS: true,
        torqueNM: true,
        claimedFE: true,
        realWorldMileage: true,
        powerTrain: true,
        // ⬇️ NEW fields
        transmissionType: true,
        transmissionSubType: true,
        drivetrain: true,
        isFourByFour: true,
      },
    });

    for (const r of rows) {
      const feRaw = r.claimedFE ?? r.realWorldMileage ?? null;
      const fe = feRaw != null ? Number(feRaw as unknown as any) : null;

      map.set(r.modelId, {
        powerPS: (r.powerPS ?? null) as number | null,
        torqueNM: (r.torqueNM ?? null) as number | null,
        mileageKMPL: fe,
        powerTrain: r.powerTrain ?? null,
        // ⬇️ NEW
        transmissionType: r.transmissionType ?? null,
        transmissionSubType: r.transmissionSubType ?? null,
        drivetrain: (r.drivetrain ?? null) as number | null,
        isFourByFour: (r.isFourByFour ?? null) as boolean | null,
      });
    }

    return map;
  }

  async listForModel(modelId: number) {
    return prisma.tblmodelpowertrains.findMany({
      where: { modelId },
      orderBy: [{ modelPowertrainId: 'asc' }],
      select: {
        modelPowertrainId: true,
        powerTrain: true,
        fuelType: true,
        transmissionType: true,
        transmissionSubType: true,
        transmissionSpeed: true,
      },
    });
  }

  async getOneWithSpecs(modelPowertrainId: number) {
    return prisma.tblmodelpowertrains.findFirst({
      where: { modelPowertrainId },
      select: {
        modelPowertrainId: true,
        modelId: true,
        powerTrain: true,
        fuelType: true,
        transmissionType: true,
        transmissionSubType: true,
        transmissionSpeed: true,

        // specs used in table
        engineDisplacement: true,
        cubicCapacity: true,
        cylinders: true,
        powerPS: true,
        powerMinRPM: true,
        powerMaxRPM: true,
        torqueNM: true,
        torqueMinRPM: true,
        torqueMaxRPM: true,
        kerbWeight: true,
        claimedFE: true,
        realWorldMileage: true,
        powerWeight: true,
        torqueWeight: true,
        drivetrain: true,
        isFourByFour: true,
      },
    });
  }

  async getWarrantyByModelIds(modelIds: number[]) {
    const map = new Map<number, { years: number | null; km: string | null }>();
    if (!modelIds?.length) return map;

    // MIN(modelPowertrainId) per modelId
    const mins = await prisma.tblmodelpowertrains.groupBy({
      by: ['modelId'],
      where: { modelId: { in: modelIds } },
      _min: { modelPowertrainId: true },
    });

    const ptIds: number[] = [];
    const midByPt = new Map<number, number>();
    for (const g of mins) {
      const mid = g.modelId as number;
      const minId = g._min.modelPowertrainId as number | null;
      if (typeof mid === 'number' && typeof minId === 'number') {
        ptIds.push(minId);
        midByPt.set(minId, mid);
      }
    }
    if (!ptIds.length) return map;

    const rows = await prisma.tblmodelpowertrains.findMany({
      where: { modelPowertrainId: { in: ptIds } },
      select: {
        modelPowertrainId: true,
        standardWarrantyKm: true,
        standardWarrantyYear: true,
      },
    });

    for (const r of rows) {
      const mid = midByPt.get(r.modelPowertrainId);
      if (!mid) continue;
      map.set(mid, {
        years: (r.standardWarrantyYear as unknown as number) ?? null,
        km: (r.standardWarrantyKm as string | null) ?? null,
      });
    }
    return map;
  }

  async getServiceSchedule(modelId: number, modelPowertrainId: number) {
    return prisma.tblperiodicmaintenancecost.findMany({
      where: { modelId, modelPowertrainId },
      orderBy: [{ id: 'asc' }],
      select: {
        id: true,
        kmDriven: true,
        cost: true,
      },
    });
  }

}
