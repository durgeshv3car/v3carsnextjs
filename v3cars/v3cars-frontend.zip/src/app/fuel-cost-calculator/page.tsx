import MainFuelCalculatorComponent from "@/components/responsive/fuel-cost-calcultor/MainFuelCalculatorComponent";

export default function Page() {

    return (
        <MainFuelCalculatorComponent />
    )
}
