import MainMileageComponent from "@/components/responsive/mileage-calculator/MainMileageComponent";

export default function Page() {

  return (
    <MainMileageComponent />
  )
}
