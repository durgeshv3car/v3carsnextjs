'use client';

import { useRouter } from 'next/navigation';
import { FaTachometerAlt, FaMoneyBillWave, FaGasPump, FaRoad, FaCalculator } from 'react-icons/fa';

const quickLinks = [
  {
    title: 'Mileage Calculator',
    description: "Estimate Your Vehicle's Fuel Efficiency",
    icon: <FaTachometerAlt size={40} />,
    bg: 'bg-[#E6F3FF]',
    href: "/mileage-calculator"
  },
  {
    title: 'Sell Used Cars',
    description: 'Sell Your Pre-Owned Car Today',
    icon: <FaMoneyBillWave size={40} />,
    bg: 'bg-[#E8FFE8]',
    href: "/sell-used-car"
  },
  {
    title: 'Fuel Price in India',
    description: 'Check Latest Fuel Prices Across India',
    icon: <FaGasPump size={40} />,
    bg: 'bg-[#FFF2D9]',
    href: "/fuel-price-in-india"
  },
  {
    title: 'Car On-road Price',
    description: 'Get On-road Price Estimates',
    icon: <FaRoad size={40} />,
    bg: 'bg-[#E8FFE8]',
    href: "/car-on-road-price-in-india"
  },
  {
    title: 'Car Loan EMI Calculator',
    description: 'Calculate Your Monthly Car Loan EMI',
    icon: <FaCalculator size={40} />,
    bg: 'bg-[#E6F3FF]',
    href: "/car-loan-emi-calculator"
  },
];

export default function QuickLinks() {
  const router = useRouter()

  return (
    <div className='px-4 lg:px-10 my-10'>
      <div className="app-container mx-auto">
        <h3 className="text-[28px] font-semibold text-gray-900 mb-4 dark:text-white">Quick Links</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {quickLinks.map((item, index) => (
            <div
              key={index}
              className={`${item.bg} rounded-lg p-4 flex flex-col items-center text-center hover:shadow-md transition cursor-pointer`}
              onClick={() => { router.push(item.href) }}
            >
              <div className="text-black mb-2">{item.icon}</div>
              <h4 className="font-semibold text-sm text-gray-900">{item.title}</h4>
              <p className="text-xs text-gray-700 mt-1">{item.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
