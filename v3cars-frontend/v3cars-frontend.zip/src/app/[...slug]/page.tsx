import DynmicSlug from "@/components/layouts/DynmicSlug";

export default function Page() {

    return <DynmicSlug />;
}