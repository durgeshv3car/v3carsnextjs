import MainOnRoadPriceComponent from "@/components/responsive/car-on-road-price/MainOnRoadPriceComponent";


function Page() {

    return (
        <MainOnRoadPriceComponent />
    );
}

export default Page;